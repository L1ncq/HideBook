const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const pdf = require('pdf-parse');

const app = express();
const PORT = 3000;

// Serve static files from the root directory
app.use(express.static(path.join(__dirname)));

// Configure multer storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    },
});

const upload = multer({ storage: storage });

// Handle the file upload at the /upload endpoint
app.post('/upload', upload.single('pdfFile'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('No file uploaded.');
    }

    const pdfPath = path.join(__dirname, req.file.path);
    const dataBuffer = fs.readFileSync(pdfPath);

    pdf(dataBuffer).then(data => {
        // Send the extracted text as a response
        const extractedText = data.text;

        // Clear the uploads folder by deleting the uploaded PDF file
        fs.unlink(pdfPath, (err) => {
            if (err) {
                console.error('Error deleting the file:', err);
            }
        });

        res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>PDF Text Output</title>
                <link rel="preconnect" href="https://fonts.googleapis.com">
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
                <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
                <link rel="stylesheet" href="Css.css">
        </head>
        <body>
                <div id="container">
                        <div id="sidebar">
                                <img src="image/sidebar.png">
                                <img id="imgBottomLeft" src="image/sidebar2.png">
                        </div>
                        <div id="sectionList">
                                <img src="image/sectionList.png">
                        </div>
                        <div id="content">
                                <h1 id="title">Uploaded PDF</h1>
                                <div id="text">
                                        <p>${extractedText}</p>
                                </div>
                                <div id="uploadDiv">
                                    <input type="file" id="fileInput" accept=".pdf" style="display: none;">
                                    <p id="fileName">Click here to upload a file</p>
                                </div>
                        </div>
                </div>
        </body>
        </html>
        `);
    }).catch(err => {
        res.status(500).send('Error parsing PDF: ' + err.message);
    });
});

// Serve the HTML form
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

