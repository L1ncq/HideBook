document.getElementById('fileUpload').addEventListener('change', function() {
    const fileNameElement = document.getElementById('fileName');
    if (this.files && this.files.length > 0) {
        fileNameElement.textContent = this.files[0].name;
    } else {
        fileNameElement.textContent = 'Click here to upload a file';
    }
});
